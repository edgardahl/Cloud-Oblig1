# Certificate of excellence

![NTNU-logo](NTNU-logo.png)

{{FirstName}} {{MiddleName}} {{LastName}} have completed the course IDG2001 Cloud Technologies at (NTNU). As part of their course, they have blabla skills, lists, etc.

his favorite car is a: {{Car}}

- SaaS, PaaS, IaaS
- Cloud infrastructure ... etc

![Signature](signature.png)

Paul Knutson, Faculty of IE, NTNU
